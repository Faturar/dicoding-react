import React from 'react'

function SearchNote() {
  return (
    <div>SearchNote</div>
  )
}

export default SearchNote